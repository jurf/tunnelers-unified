using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace unityIRCclient
{
	public class FarrisArts_IRC
	{
		public delegate void RecieveMessage(string msg);
		public RecieveMessage recieveMessage;
		
		// Irc server to connect 
	    public const string SERVER = "irc.freenode.net";
	
	    // Irc server's port (6667 is default port)
	    private const int PORT = 6667;
	
	    // User information defined in RFC 2812 (Internet Relay Chat: Client Protocol) is sent to irc server 
	    private const string USER = "USER __NAME_HERE__ 0 * :NameTest";
	
	    // Channel to join
	    private const string CHANNEL = "#unity3d";
	
	    // Users nickname
	    public string nick = string.Empty;
	    public string backupNick = string.Empty;
	
	    // StreamWriter is declared here so that PingSender can access it
	    public static StreamWriter writer;
		private StreamReader reader;
		private NetworkStream stream;
		
		public int sleepTime = 2000;
		
		private TcpClient irc;
		
		public bool Connected { get { return irc.Connected; } }
		
		public bool changeInUsers = false;
		public List<string> users = new List<string>();
		
		private PingSender ping;

		public bool disconnecting = false;
		
		public void Disconnect(bool retry)
		{
			if (!retry && File.Exists("running.lock"))
				File.Delete("running.lock");
			
			if (irc.Connected)
			{
				users.Clear();
				writer.Close();
	            reader.Close();
				irc.Close();
				if (!retry)
				{
					ping.Stop();
					recieveMessage = null;
				}
			}

			if (retry)
				Connect(backupNick, string.Empty);
		}
		
		public void AddUser(string user)
		{
			if (!users.Contains(user))
			{
				users.Add(user);
				users.Sort();
				changeInUsers = true;
			}
		}
		
		public void RemoveUser(string user)
		{
			users.Remove(user);
			changeInUsers = true;
		}
		
		public void SendMessage(string message, string prvMsg)
		{
			if (irc.Connected)
			{
				if (string.IsNullOrEmpty(prvMsg.Trim()))
					writer.WriteLine("PRIVMSG #unity3d :" + message);
				else
					writer.WriteLine("PRIVMSG " + prvMsg + " :" + message);
					
	    	    writer.Flush();
			}
		}
		
		public void Connect(string nickname, string backupNickname)
		{
			if (!File.Exists("running.lock"))
				File.Create("running.lock");
			
			nickname = nickname.Replace(" ", "");
			backupNickname = backupNickname.Replace(" ", "");
			
			try
			{
				irc = new TcpClient(SERVER, PORT);
	            stream = irc.GetStream();
	            reader = new StreamReader(stream);
	            writer = new StreamWriter(stream);
				
				// Start PingSender thread
	            ping = new PingSender();
	            ping.Start();
				
				nick = nickname;
				backupNick = backupNickname;
	            writer.WriteLine(USER.Replace("__NAME_HERE__", nick));
	            writer.Flush();
				
		        writer.WriteLine("NICK " + nickname);
	            writer.Flush();
				
	            writer.WriteLine("JOIN " + CHANNEL);
	            writer.Flush();
				
				writer.WriteLine("NAMES " + CHANNEL);
	            writer.Flush();
			}
			catch
			{
				// Couldn't connect
			}
		}
		
	    public void Listen()
	    {
	        string inputLine;
	        string nickname;
	
	        try
	        {
	            while ((inputLine = reader.ReadLine()) != null)
	            {
	                if (inputLine.EndsWith("JOIN :" + CHANNEL))
	                {
	                    // Parse nickname of person who joined the channel
	                    nickname = inputLine.Substring(1, inputLine.IndexOf("!") - 1);
	
	                    // Welcome the nickname to channel by sending a notice
	                    //writer.WriteLine ("NOTICE " + nickname + " :Hi " + nickname + " and welcome to " + CHANNEL + " channel!");
	                    //writer.Flush();
						
						if (recieveMessage != null)
						{
							recieveMessage("SERVER: >>> " + nickname + " has joined the channel <<<");
							AddUser(nickname);
						}
	                    
	
	                    // Sleep to prevent excess flood
	                    Thread.Sleep(sleepTime);
	                }
	                else
	                {
	                    if (inputLine.Contains("* " + nick + " :Nickname is already in use."))
	                    {
							MainClass.messageBuffer.Add("SERVER: >>> That Nickname is already in use, click disconnect and try another. <<<");
							disconnecting = true;
							//Disconnect(true);
							break;
	                    }
	                    else
	                    {
	                        string mail = inputLine.Remove(0, 1);
	                        string[] tmpArr = mail.Split('!');
	
	                        string rNick = tmpArr[0];
	
	                        if ((tmpArr.Length > 1 && !rNick.Contains(" PONG ")) || tmpArr[0].StartsWith(tmpArr[0].Split('.')[0] + ".freenode.net 353 "))
	                        {
								if (tmpArr.Length > 1)
		                            tmpArr = tmpArr[1].Split(':');
								else
									tmpArr = tmpArr[0].Split(':');
	
	                            if (tmpArr[0].Contains(" QUIT "))
								{
	                                if (recieveMessage != null)
									{
										recieveMessage("SERVER: >>> " + rNick + " has left <<<");
										RemoveUser(rNick);
									}
								}
	                            else if (tmpArr[0].Contains("PRIVMSG"))
	                            {
	                                string msgType = tmpArr[0].Split(new string[] { " PRIVMSG " }, StringSplitOptions.RemoveEmptyEntries)[1].Split(' ')[0];
	
	                                //:Valentine!~Valentine@c-66-41-4-67.hsd1.mn.comcast.net PRIVMSG #unity3d :so x,y,z
	
	                                if (msgType == "#unity3d")
	                                {
	                                    // Public Message
	                                    if (recieveMessage != null)
											recieveMessage("PUBLIC: " + rNick + "> " + tmpArr[1]);
	                                }
	                                else if (msgType == nick)
	                                {
	                                    // Private Message
	                                    if (recieveMessage != null)
											recieveMessage("PRIVATE: " + rNick + "> " + tmpArr[1]);
	                                }
	                            }
								else if (rNick.StartsWith(rNick.Split('.')[0] + ".freenode.net 353 "))
								{
									string[] aNames = inputLine.Remove(0, 1).Split(':')[1].Split(' ');
									foreach (string s in aNames)
										if (!users.Contains(s))
											users.Add(s);
									
									users.Sort();
								}
	                        }
	                    }
	                }
	            }
	        }
	        catch (Exception e)
	        {
	            // Show the exception, sleep for a while and try to establish a new connection to irc server
	            if (recieveMessage != null)
					recieveMessage(e.ToString());
	        }
	    }
	}
}