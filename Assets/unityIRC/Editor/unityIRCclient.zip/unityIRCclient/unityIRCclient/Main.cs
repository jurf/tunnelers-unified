using System;
using System.IO;
using System.ComponentModel;
using System.Collections.Generic;

namespace unityIRCclient
{
	class MainClass
	{
		private static BackgroundWorker bgwkr;
		public static FarrisArts_IRC irc = new FarrisArts_IRC();
		
		private static string nameChosen = string.Empty;
		public static List<string> messageBuffer = new List<string>();
		
		public static DateTime lastRead;
		
		private static bool initialUsers = false;
		
		public static void Main (string[] args)
		{
			if (args.Length > 1)
			{
				string username = args[0];
				string backup = args[1];
				
				bgwkr = new BackgroundWorker();
				bgwkr.WorkerSupportsCancellation = true;
				bgwkr.DoWork += new DoWorkEventHandler(bgwkr_DoWork);
				
				irc.sleepTime = 200;
			
				irc.Connect(username, backup);
				
				if (irc.Connected)
				{
					irc.recieveMessage = RecieveMessage;
					
					nameChosen = username;
					bgwkr.RunWorkerAsync(irc);
					messageBuffer.Add("SERVER: >>> Logging into irc.freenode.net as " +  nameChosen + " <<<");
					Console.WriteLine(messageBuffer[messageBuffer.Count - 1]);
					
					lastRead = File.GetLastWriteTime("sendMsg.log");
				}
				
				int lastMsgCount = 0;
				while (irc.Connected)
				{
					if (messageBuffer.Count > lastMsgCount)
					{
						try
						{
							string msg = string.Empty;
							
							foreach (string m in messageBuffer)
								msg += m + "\r\n";

							File.WriteAllText("irc.log", msg);
							
							lastMsgCount = messageBuffer.Count;

							if (irc.disconnecting)
							{
								irc.Disconnect(false);
								break;
							}
						}
						catch { }
					}
					
					if (irc.changeInUsers && irc.users.Count != 0)
					{
						try
						{
							string usrs = string.Empty;
							
							foreach (string u in irc.users)
								usrs += u + "\r\n";
							
							File.WriteAllText("userList.log", usrs);
							initialUsers = true;
							irc.changeInUsers = false;
						}
						catch { }
					}
					
					if (File.GetLastWriteTime("sendMsg.log") != lastRead)
					{
						try
						{
							string[] contents = File.ReadAllText("sendMsg.log").Replace("\r", "").Split('\n');
							
							foreach (string c in contents)
							{
								if (!string.IsNullOrEmpty(c.Trim()))
									SendMessage(c);
							}
							
							File.WriteAllText("sendMsg.log", string.Empty);
							
							lastRead = File.GetLastWriteTime("sendMsg.log");
						}
						catch { }
					}
				}
			}
		}
		
		// This event handler is where the time-consuming work is done. 
	    private static void bgwkr_DoWork(object sender, DoWorkEventArgs e)
	    {
	        //BackgroundWorker worker = sender as BackgroundWorker;
			
			FarrisArts_IRC i = (FarrisArts_IRC)e.Argument;
			
			i.Listen();
	    }
		
		private static void SendMessage(string msg)//, SendType sendType)
		{
			if (!initialUsers)
				irc.changeInUsers = true;
			
			if (msg == ">>> Disconnect <<<")
				Disconnect();
			else if (msg.StartsWith("!pvt "))
			{
				string pvtName = msg.Remove(0, 5).Split('!')[0];
				string fixedMsg = msg.Remove(0, 1).Replace(msg.Remove(0, 1).Split('!')[0] + "!", "").Trim();
				irc.SendMessage(fixedMsg, pvtName);
				messageBuffer.Add("MYMSG: ~" + pvtName + "~" + nameChosen + ">" + fixedMsg);
				Console.WriteLine(messageBuffer[messageBuffer.Count - 1]);
			}
			else
			{
				irc.SendMessage(msg, string.Empty);
				messageBuffer.Add("MYMSG: " + nameChosen + ">" + msg);
				Console.WriteLine(messageBuffer[messageBuffer.Count - 1]);
			}
		}
		
		public static void RecieveMessage(string msg)
		{
			messageBuffer.Add(msg);
			Console.WriteLine(messageBuffer[messageBuffer.Count - 1]);
			
			if (!initialUsers)
				irc.changeInUsers = true;
		}
		
		public static void Disconnect()
		{
			messageBuffer.Clear();
			bgwkr.CancelAsync();
			irc.Disconnect(false);
		}
	}
}
