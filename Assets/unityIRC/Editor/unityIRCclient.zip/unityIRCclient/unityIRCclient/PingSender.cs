using System;
using System.Threading;

namespace unityIRCclient
{
	public class PingSender
	{
		static string PING = "PING :";
	    private Thread pingSender;
	
	    // Empty constructor makes instance of Thread
	    public PingSender() 
	    {
	        pingSender = new Thread (new ThreadStart (this.Run) ); 
	    }
	
	    // Starts the thread
	    public void Start() 
	    { 
	        pingSender.Start(); 
	    }
		
		public void Stop()
		{
			pingSender.Abort();
		}
	
	    // Send PING to irc server every 15 seconds
	    public void Run()
	    {
	        while (true)
	        {
	            try
	            {
	                FarrisArts_IRC.writer.WriteLine(PING + FarrisArts_IRC.SERVER);
	                FarrisArts_IRC.writer.Flush();
	                Thread.Sleep(15000);
	            }
	            catch { break; }
	        }
	    }
	}
}